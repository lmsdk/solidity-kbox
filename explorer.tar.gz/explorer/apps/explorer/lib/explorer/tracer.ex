defmodule Explorer.Tracer do
  @moduledoc false

  use Spandex.Tracer, otp_app: :explorer
end
