defmodule EthereumJSONRPC.Tracer do
  @moduledoc false

  use Spandex.Tracer, otp_app: :ethereum_jsonrpc
end
