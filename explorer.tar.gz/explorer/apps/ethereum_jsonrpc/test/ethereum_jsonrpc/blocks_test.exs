defmodule EthereumJSONRPC.BlocksTest do
  use ExUnit.Case, async: true

  doctest EthereumJSONRPC.Blocks
end
