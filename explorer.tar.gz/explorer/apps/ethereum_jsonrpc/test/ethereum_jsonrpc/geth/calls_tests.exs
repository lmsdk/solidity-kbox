defmodule EthereumJSONRPC.Geth.CallsTest do
  use ExUnit.Case, async: true

  doctest EthereumJSONRPC.Geth.Calls
end
