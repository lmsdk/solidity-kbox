defmodule EthereumJSONRPC.Parity.TraceTest do
  use ExUnit.Case, async: true

  doctest EthereumJSONRPC.Parity.Trace
end
