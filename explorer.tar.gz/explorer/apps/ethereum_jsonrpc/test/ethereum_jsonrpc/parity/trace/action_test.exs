defmodule EthereumJSONRPC.Parity.Trace.ActionTest do
  use ExUnit.Case, async: true

  doctest EthereumJSONRPC.Parity.Trace.Action
end
