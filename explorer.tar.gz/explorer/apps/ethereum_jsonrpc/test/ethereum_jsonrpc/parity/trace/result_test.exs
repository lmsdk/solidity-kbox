defmodule EthereumJSONRPC.Parity.Trace.ResultTest do
  use ExUnit.Case, async: true

  doctest EthereumJSONRPC.Parity.Trace.Result
end
